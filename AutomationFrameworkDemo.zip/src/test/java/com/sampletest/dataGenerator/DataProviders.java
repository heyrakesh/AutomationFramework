package com.sampletest.dataGenerator;

import org.testng.annotations.DataProvider;

import com.sampletest.util.ExcelUtil;


public class DataProviders {
	
	 @DataProvider(name = "successLoginDataSet")
	    public Object[][] getValidDataFromDataProvider(){
	    	String[][] testData = null;
			try {
				testData = ExcelUtil.getExcelDataIn2DArray("testData//validLoginTestData.xlsx", "loginSheet");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return testData;
	    }
	
	
    @DataProvider(name = "failedLoginDataSet")
    public Object[][] getDataFromDataProvider(){
    	String[][] testData = null;
		try {
			testData = ExcelUtil.getExcelDataIn2DArray("testData//loginTestData.xlsx", "loginSheet");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testData;
    }
}
