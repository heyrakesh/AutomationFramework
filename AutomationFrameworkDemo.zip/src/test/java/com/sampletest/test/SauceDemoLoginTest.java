package com.sampletest.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sampletest.base.TestBase;
import com.sampletest.dataGenerator.DataProviders;
import com.sampletest.pages.SauceDemoInventoryPage;
import com.sampletest.pages.SauceDemoLoginPage;

public class SauceDemoLoginTest extends TestBase{

	SauceDemoLoginPage loginPage;
	

	//Log4j configuration
	private static final Logger log = LogManager.getLogger(SauceDemoLoginTest.class);
	
	@Test(dataProvider = "successLoginDataSet", dataProviderClass = DataProviders.class)
	public void loginTest(String username, String password){
		
		log.info("Verifying successful login.");
		
		loginPage = new SauceDemoLoginPage(driver);
		
		SauceDemoInventoryPage inventoryPage = loginPage.login(username, password);
		String expectedProductLabel = "Products";
		String actualProductLabel = inventoryPage.getProductLabel();
		
		log.info("expectedProductLabel-" + expectedProductLabel + " and actualProductLabel - " + actualProductLabel);
		Assert.assertEquals(expectedProductLabel, actualProductLabel);
	}
	
	
	
	   @Test(dataProvider = "failedLoginDataSet", dataProviderClass = DataProviders.class)
		public void failedLoginTest(String username, String password, String error){
			
			log.info("Verifying login is failed with invalid credentials.");
			
			loginPage = new SauceDemoLoginPage(driver);
			
			loginPage.login(username, password);
			String actualError=loginPage.returnErrorNotification();
			
			log.info("expectedEror-" + error + " and actualError - " + actualError);
			Assert.assertEquals(error, actualError);
		}	
	
	

}
