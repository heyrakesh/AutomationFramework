package com.sampletest.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sampletest.base.TestBase;
import com.sampletest.pages.SauceDemoInventoryPage;
import com.sampletest.pages.SauceDemoLoginPage;
import com.sampletest.pages.SauceDemoShoppingCartPage;


public class SauceDemoAddItemToCartTest extends TestBase{

	SauceDemoLoginPage loginPage;
	

	//Log4j configuration
	private static final Logger log = LogManager.getLogger(SauceDemoAddItemToCartTest.class);
	
		
	@Test
	public void addItemToCartTest(){
		
		log.info("Verifying successful login.");
		
		loginPage = new SauceDemoLoginPage(driver);
		
		SauceDemoInventoryPage inventoryPage = loginPage.login("standard_user", "secret_sauce");
		SauceDemoShoppingCartPage shoppingcartPage=inventoryPage.addRandomToCart();
		
		boolean isItemAdded=shoppingcartPage.itemInCart();
		log.info("Item is added to the cart-" + isItemAdded );
		Assert.assertTrue(isItemAdded);		
				
		//remove the item from cart
		shoppingcartPage.removeItemFromCart();
	}
	
	
	
	

}
