package com.sampletest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SauceDemoShoppingCartPage {

	WebDriver driver;

	
	@FindBy(xpath="//button[contains(@id,'add-to-cart')]")
	WebElement allAddToCartButtonsBy;
	
	@FindBy(xpath="//button[text()='Remove']")
	WebElement removeButtonBy;

	
	public SauceDemoShoppingCartPage(WebDriver driver) {
		this.driver = driver;
        PageFactory.initElements(driver, this);
	}
		
	
	public boolean itemInCart() {

		return removeButtonBy.isDisplayed();
	}
	
	public void removeItemFromCart() {
		removeButtonBy.click();
	}
    
	
	
}
