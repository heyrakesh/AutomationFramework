package com.sampletest.pages;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SauceDemoInventoryPage {

	WebDriver driver;
	
//	@FindBy(css="div.product_label")
	@FindBy(className="title")
	WebElement productLabel;
	
	/*
	 * @FindBy(xpath="//button[contains(@id,'add-to-cart')]") WebElement
	 * allAddToCartButtonsBy;
	 */
	
	By allAddToCartButtonsBy = By.xpath("//button[contains(@id,'add-to-cart')]");

	
	public SauceDemoInventoryPage(WebDriver driver) {
		this.driver = driver;
        PageFactory.initElements(driver, this);
	}
	
	
	public String getProductLabel() {
		return productLabel.getText();
	}	
	
    public WebElement selectRandomWebElement(By elementLocator){
        List<WebElement> itemList = driver.findElements(elementLocator);
        Random random = new Random();
        int size = itemList.size();
        int selection = random.nextInt(size-1);
        return itemList.get(selection);
    }
    
	/*
	 * public void addRandomToCart(){
	 * 
	 * selectRandomWebElement(allAddToCartButtonsBy) allAddToCartButtonsBy.click();
	 * }
	 */
	
    
    public SauceDemoShoppingCartPage addRandomToCart(){
        WebElement element = selectRandomWebElement(allAddToCartButtonsBy);
        element.click();
        return new SauceDemoShoppingCartPage(driver);
    }
	
}
