package com.sampletest.util;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {
	private static String url;
	private static PropertyManager instance;

	public static PropertyManager getInstance(String propertyFile) {
		if (instance == null) {
			instance = new PropertyManager();
			instance.loadData(propertyFile);
		}
		return instance;
	}

	private void loadData(String propertyFile) {
		Properties properties = new Properties();

		try {
			FileInputStream fi = new FileInputStream(propertyFile);
			properties.load(fi);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		url = properties.getProperty("baseUrl");

	}

	public String getUrl() {
		return url;
	}

}
